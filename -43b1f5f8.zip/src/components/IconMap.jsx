
import { 
    Store, Building, Building2, Home, MapPin, 
    UtensilsCrossed, Coffee, Utensils, Pizza, Soup,
    Crown, Star, Award, Trophy, Medal,
    ShoppingBag, ShoppingCart, Package, Gift,
    Heart, Smile, ThumbsUp, CheckCircle, Circle,
    Mountain, Sun, Moon, Flower, TreePine,
    FileText, UserCheck, Truck, User, Users, MessageSquare, Music
} from 'lucide-react';

export const iconMap = {
    Store, Building, Building2, Home, MapPin, UtensilsCrossed, Coffee,
    Utensils, Pizza, Soup, Crown, Star, Award, Trophy, Medal,
    ShoppingBag, ShoppingCart, Package, Gift, Heart, Smile, ThumbsUp,
    CheckCircle, Circle, Mountain, Sun, Moon, Flower, TreePine,
    FileText, UserCheck, Truck, User, Users, MessageSquare, Music
};
