import React from 'react';
import InitiatedAuditFormComponent from '../components/InitiatedAuditForm';

export default function InitiatedAuditFormPage() {
    return (
        <InitiatedAuditFormComponent />
    );
}